<div class="p-4 row g-3">
    {{ $slot }}
</div>
