<span class="ms-2 text-danger small">*</span>
