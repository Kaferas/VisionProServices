<div class="d-flex align-items-center px-4 py-3 border-bottom position-relative">
    <h2 class="h6 text-center me-auto mb-0">
        {{ $slot }}
    </h2>
    <div>
        <a href="javascript:;" data-bs-dismiss="modal" class="btn-close position-absolute top-0 end-0 m-3" aria-label="Close"></a>
    </div>
</div>
